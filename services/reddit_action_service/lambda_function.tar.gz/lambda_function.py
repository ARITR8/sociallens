import json
import requests
import os

def lambda_handler(event, context):
    # Get parameters from Bedrock Agent
    subreddit = event.get('subreddit', 'Python')
    limit = event.get('limit', 5)
    
    # Call existing Reddit service
    reddit_url = f"https://wzlvrmaf3d.execute-api.us-east-1.amazonaws.com/prod/api/v1/fetcher/posts/{subreddit}?limit={limit}"
    
    try:
        response = requests.get(reddit_url)
        posts = response.json()
        
        # Return simple format for Bedrock Agent
        return {
            'statusCode': 200,
            'body': json.dumps({
                'subreddit': subreddit,
                'posts': posts,
                'message': f'Found {len(posts)} posts from r/{subreddit}'
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }